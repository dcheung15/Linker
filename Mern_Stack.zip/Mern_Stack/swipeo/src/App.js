import logo from './logo.svg';
import './App.css';
import SignUp from "./signUp";
import { BrowserRouter as Router, Switch, Route} from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="app">
        <Switch>
        <Route path="/s">
            <h1>o</h1>
          </Route>
          <Route path="/">
          <SignUp/>
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

export default App;
