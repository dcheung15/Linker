import React, {useState} from 'react';
import {Link, useHistory} from 'react-router-dom';

function SignUp(){
    return(
    <div>
    <script src="scripts.js"></script>

    <div class="projectMenu">
        <a class="active" href="index.html">Home</a>
        <a href="about.html">About</a>
        <a href="logIn.html">Log In</a>
        <a href="signUp.html">Sign Up</a>
    </div>         
            <form>
                <lottie-player
                  src="https://assets4.lottiefiles.com/datafiles/XRVoUu3IX4sGWtiC3MPpFnJvZNq7lVWDCa8LSqgS/profile.json"
                  background="transparent"
                  speed="1"
                  style="justify-content: center"
                  loop
                  autoplay
                ></lottie-player>
                <input type="text" placeholder="full name" />
                <input type="text" placeholder="email address" />
                <input type="text" placeholder="pick a username" />
                <input type="password" id="password" placeholder="set a password" />
                <i class="fas fa-eye" onclick="show()"></i>
            
              </form>
    
              
                <button type="button" onclick="window.location.href='login.html'">
                  SIGN UP
                </button>

                </div>
            
            
    

    );
};

export default SignUp;