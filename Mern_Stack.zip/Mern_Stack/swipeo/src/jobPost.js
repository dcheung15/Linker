import React, {useState} from 'react';
//import './jobPost.css';
import {Link, useHistory} from 'react-router-dom';


export default JobPost