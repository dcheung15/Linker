const userSchema = mongoose.Schema({
    passwordHash: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    userName: { type: String, required: true, unique: true },
    userType: { type: String, required: true },
    location: { type: String},
    fullName: { type: String, required: true }
    userID: { type: String, unique: true }
    created: { type: Date, default : () => new Date()}
})