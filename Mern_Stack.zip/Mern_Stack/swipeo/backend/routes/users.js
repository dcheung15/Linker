const User = require('../models/User_model');
const express = require('express');
const router = express.Router();
  
    //Returns Jsonlist of all users
  router.get('/', async (req,res) =>{
    //res.send('we are on Users page');
    try{
        const users = await User.find();
        res.json(users);
        //Post.find.limit
    }
    catch(err){res.json({message:err})
    }
    return;
  });

  //adds new user to db
  router.get('/more',(req,res) =>{
    res.send('Now we are on them ones');
  });

  router.post('/', async (req,res) => {
      //print request
      //console.log(req.body);
      const user = new User({
          username: req.body.username,
          password: req.body.password
      });
      try {
          const newUser = await user.save();
          res.json(newUser);
      } catch(err){
          res.json({message:err})
      }
  });

  //RETURN SPECIFIC USER
  router.get('/:userId',async  (req,res) => {
      //console.log(req.params._id);
      //console.log(req.params.userId);
      try{
      const user = await User.findById(req.params.userId);
      res.json(user);}
      catch(err){
          res.json({message:err});
      }
  });

  //DELETE SPECIFIC USER
  router.delete('/:userId', async (req,res) =>{
      try{
      const deletedUser = await User.remove({_id: req.params.userId});
    res.json(deletedUser);
    }
      catch(err){
          res.json({message:err})
      }
  });

  //UPDATE SPECIFIC USER
  router.patch('/:userId', async (req,res) => {
      try{
      const updateduser = await User.updateOne({_id:req.params.userId}, 
        {$set:{username: req.body.username}}
        );
        res.json(updateduser);


      } catch(err){
          res.json({message:err});

      }
  })


  module.exports = router;