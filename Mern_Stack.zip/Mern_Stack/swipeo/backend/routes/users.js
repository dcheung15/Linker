const User = require('../models/User_model');
const express = require('express');
const router = express.Router();
  
  router.get('/', async (req,res) =>{
    //res.send('we are on Users page');
    try{
        const users = await Post.find();
        res.json(users);
        //Post.find.limit
    }
    catch(err){res.json({message:err})
    }
    return;
  });

  router.get('/more',(req,res) =>{
    res.send('Now we are on them ones');
  });

  router.post('/', async (req,res) => {
      //print request
      //console.log(req.body);
      const user = new User({
          username: req.body.username,
          password: req.body.password
      });
      try {
          const newUser = await user.save();
          res.json(newUser);
      } catch(err){
          res.json({message:err})
      }
  });


  module.exports = router;