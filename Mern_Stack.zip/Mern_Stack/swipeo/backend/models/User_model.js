const mongoose = require('mongoose');

const UserSchema = mongoose.Schema({
    username:String,
    password:{
        type: String,
        required: true
    },
});


module.exports = mongoose.model('Users',UserSchema);