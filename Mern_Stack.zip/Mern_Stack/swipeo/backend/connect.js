const express = require('express');
const dotenv = require('dotenv');
const morgan = require('morgan');
const mongoose = require('mongoose');

const bodyparser = require('body-parser');

const app = express(); 

dotenv.config({path:'.env'})
const PORT = process.env.PORT || 8080


//Middlewares 
//functions that will be run when certain routes are used
/*
example middleware
prints to console everytime posts route is called

app.use('/posts',() => {
  console.log("This is some middle ware running");
}); 


//authenticator middleware
app.use(auth);
*/


//log requests
app.use(morgan('tiny'));

//pars request
app.use(bodyparser.urlencoded({extended:true}));
app.use(bodyparser.json());

//Import Routes
const userRoute = require('./routes/users');
//middleware
app.use('/users',userRoute);

//load routers
//ROUTES
app.get('/',(req,res) =>{
  res.send('we are on home');
});


app.listen(PORT,()=>{console.log('Server is running localhost')});


// Connect to the db
//var MongoClient = require('mongodb').MongoClient;

console.log('connecting to db');
mongoose.connect("mongodb+srv://jbesong:GetJobSwiping@cluster0.bttlo.mongodb.net/Users?retryWrites=true?authSource=admin", function(err, db) {
  if(!err) {
    console.log("We are connected");
    console.log("Let's create an collection");

    /*
    const myawesomedb = db('myawesomedb');
    var collection = myawesomedb.collection('ThecollectionIWantOAcess');
    console.log('Collection Created');
    var doc1 = {'hello' : 'doc1'};
    var doc2 = {'hello': 'doc2'};
    var lotsofDocs = [{'hello':'doc3'}, {'hello':'doc4'}];
    collection.insert(doc1);
    console.log("This is collection created");
    console.log(collection); */
    

    /*
    var collection = db.collection('test');
    var doc1 = {'hello':'doc1'};
    var doc2 = {'hello':'doc2'};
    var lotsOfDocs = [{'hello':'doc3'}, {'hello':'doc4'}];

  collection.insert(doc1);

  collection.insert(doc2, {w:1}, function(err, result) {});

  collection.insert(lotsOfDocs, {w:1}, function(err, result) {});

  
  console.log("This is collection...: ")
  console.log(collection)
  */

    console.log("end of connection loop &&&&&&&&&&&&&&&&&&")
    //console.log(MongoClient.db().admin())
  }
  else{console.log('we are NOT CONNECTED');
console.log(err);
console.log("End of errors ****************");}
});