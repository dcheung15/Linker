// Retrieve
var MongoClient = require('mongodb').MongoClient;

console.log('connecting to db');
// Connect to the db
MongoClient.connect("mongodb+srv://jbesong:GetJobSwiping@cluster0.bttlo.mongodb.net/Users?retryWrites=true&w=majority?authSource=admin", function(err, db) {
  if(!err) {
    console.log("We are connected");
    console.log(db);
    console.log("end of connection loop &&&&&&&&&&&&&&&&&&")
    //console.log(MongoClient.db().admin())
  }
  else{console.log('we are NOT CONNECTED');
console.log(err);
console.log("End of errors ****************");}
});