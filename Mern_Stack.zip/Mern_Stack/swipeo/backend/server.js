const express = require('express'); 
const cors = require('cors');
//const {MongoClient} = require('mongodb');
const {MongoClient} = require('mongodb').MongoClient;

//require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000; 

//cors middle ware
app.use(cors());
app.use(express.json());

//connection to database
//database stored in uri in .env file
const uri = "mongodb+srv://jbesong:GetJobSwiping@cluster0.bttlo.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
//const client = new MongoClient(uri,{useNewUrlParser: true, useUnifiedTopology:true});
/*
const client = new MongoClient(uri);

    try {
        client.connect();
        console.log(client.db().admin().listDatabases())
        console.log("*************successfully connected")
    
    } catch (e) {
        console.log("*************Error message")
        console.error(e);
    } */
    

    /*
client.connect(err => {
    const collection = client.db("test").collection("devices");

    client.once('open', () => {
        console.log('MongoDB database connection established successfully');
    })

    console.log("This is mongo error")
    console.log(err)
    


    client.close();
});
*/



app.listen(port, () => {
    console.log(`Server is running on port: ${port}`);
});

